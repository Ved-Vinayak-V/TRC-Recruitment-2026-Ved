
#define TRIG_PIN 5
#define ECHO_PIN 18 
#define LDR_PIN 35
#define LED_PIN 2


long duration;
float distanceCm;
int ldrValue;
int ledBrightness;

void setup() {
  Serial.begin(115200);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);

  digitalWrite(LED_PIN, LOW);
  Serial.println("Smart Parking Assistant Initializing...");
  delay(1000);
}

void loop() {
 
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  duration = pulseIn(ECHO_PIN, HIGH);
  distanceCm = duration * 0.0343 / 2.0;


  ldrValue = analogRead(LDR_PIN);
  ledBrightness = map(ldrValue, 0, 4095, 50, 255); 


  Serial.print("Distance: ");
  Serial.print(distanceCm);
  Serial.print(" cm | Ambient Light LDR: ");
  Serial.print(ldrValue);


  if (distanceCm > 0 && distanceCm < 10.0) {
    analogWrite(LED_PIN, ledBrightness);
    Serial.println(" | Status: SOLID ON (STOP!)");
    delay(2000);
  } 
  else if (distanceCm >= 10.0 && distanceCm < 20.0) {
    Serial.println(" | Status: BLINKING FAST (CAUTION)");
    analogWrite(LED_PIN, ledBrightness);
    delay(1000);
    analogWrite(LED_PIN, 0);
    delay(1000);
  } 
  else {
    analogWrite(LED_PIN, 0);
    Serial.println(" | Status: SAFE (LED OFF)");
    delay(2000);
  }
}