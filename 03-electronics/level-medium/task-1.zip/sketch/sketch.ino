#include <DHT.h>

#define DHTPIN 23 
#define DHTTYPE DHT22
#define MQ_PIN 34
#define LED_PIN 18

#define GAS_THRESHOLD 1500

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  dht.begin();
  
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  
  Serial.println("Air Quality Monitor Initializing...");
  delay(2000);

void loop() {
 
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();
  int gasLevel = analogRead(MQ_PIN);

 
  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("Error: Failed to read from DHT sensor!");
    return;
  }

  Serial.print("Temp: ");
  Serial.print(temperature);
  Serial.print(" °C | Humidity: ");
  Serial.print(humidity);
  Serial.print(" % | Gas Level: ");
  Serial.print(gasLevel);

  if (gasLevel > GAS_THRESHOLD && humidity > 70.0) {
    digitalWrite(LED_PIN, HIGH);
    Serial.println("   --> ALERT: Unsafe air quality detected!");
  } else {
    digitalWrite(LED_PIN, LOW); 
    Serial.println("   --> Status: Safe");
  }

  delay(2000); // Read every 2 seconds
}